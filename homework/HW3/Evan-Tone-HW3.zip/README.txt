
FILE DESCRIPTIONS

- Coordinator.c
Coordinated forking, execution, and waiting for child processes.

- Checker.c
Checks if an integer argument is divisible by another integer argument.


USAGE

compile with "make all"

run with "coordinator [int divisor] [int dividend]" where there are as many [int dividend]s as needed