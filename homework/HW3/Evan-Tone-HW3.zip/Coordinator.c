#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(int argc, char *argv[]) {
    char *divisor = argv[1];
    int fd[4][2];

    for (int i = 0; i < 4; i++) {
        pipe(fd[i]);
    }


    for (int i = 0; i < 4; i++) {
        pid_t pid = fork();

        char *dividend = argv[i+2];

        // fork failed
        if (pid == -1) {
            printf("Coordinator: Fork failed.\n");
        }
        // current process is child
        else if (pid == 0) {
            char buffer[8];
            sprintf(buffer, "%d", fd[i][0]);
            execl("./checker", "checker", divisor, dividend, buffer, NULL);
        }
        // current process is parent
        else {
            printf("Coordinator: forked process with ID %d.\n", pid);
            close(fd[i][0]);
            int shmId = shmget(IPC_PRIVATE, sizeof(int), IPC_CREAT | 0666);
            write(fd[i][1], &shmId, sizeof(shmId));
            printf("Coordinator: wrote shm ID %d to pipe (%ld bytes)\n", shmId, sizeof(shmId));
            close(fd[i][1]);

            int status;
            printf("Coordinator: waiting for process [%d].\n", pid);
            wait(&status);
            
            if (WIFEXITED(status)) {
                int *shmPointer = (int*)shmat(shmId, NULL, 0);
                if (*shmPointer == 0) {
                    printf("Coordinator: result 0 read from shared memory: %c is not divisible by %c.\n", *dividend, *divisor);
                } else if (*shmPointer == 1) {
                    printf("Coordinator: result 1 read from shared memory: %c is divisible by %c.\n", *dividend, *divisor);
                } else {
                    printf("Coordinator: Incorrect value in shared memory.\n");
                }
                shmctl(*shmPointer, IPC_RMID, NULL);
            }
            else if (WIFSIGNALED(status)) {
                printf("Coordinator: child process %d terminated due to signal %d\n", pid, WTERMSIG(status));
            }
        }
    }
    printf("Coordinator: exiting.\n");
}

