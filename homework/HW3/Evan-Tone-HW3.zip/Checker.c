#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(int argc, char *argv[]) {
    pid_t pid = getpid();
    printf("Checker process [%d]: Starting.\n", pid);

    int divisor = atoi(argv[1]);
    int dividend = atoi(argv[2]);
    int fd = atoi(argv[3]);
    int shmId;

    read(fd, &shmId, sizeof(shmId));
    printf("Checker process [%d]: read %ld bytes containing shm ID %d.\n", pid, sizeof(shmId), shmId);

    int* shmPointer = (int*)shmat(shmId, NULL, 0);

    // inputs are assumed to be positive as per assignment description
    if (dividend % divisor == 0) {
        printf("Checker process [%d]: %d *IS* divisible by %d.\n", pid, dividend, divisor);
        *shmPointer = 1;
        printf("Checker process [%d]: wrote result (1) to shared memory.\n", pid);
    }
    else {
        printf("Checker process [%d]: %d *IS NOT* divisible by %d.\n", pid, dividend, divisor);
        *shmPointer = 0;
        printf("Checker process [%d]: wrote result (0) to shared memory.\n", pid);
    }

    shmdt(shmPointer);

    return 0;
}