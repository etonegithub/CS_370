public class Consumer implements Runnable{
    
    BoundedBuffer buffer;
    Double totalRemoved = 0.0; // sum of all removals
    int maxToRemove;
    int checkpoint;

    public Consumer(BoundedBuffer buff, int maxToRemove, int checkpoint) {
        this.buffer = buff;
        this.maxToRemove = maxToRemove;
        this.checkpoint = checkpoint;
    }

    @Override
    public void run() {
        for (int i = 0; i <= maxToRemove; i++) {
            // remove from buffer and add to total
            totalRemoved += buffer.remove();

            // Print updates on predefined checkpoints
            if (i != 0 && (i) % checkpoint == 0) {
                System.out.printf("Consumer: Consumed %d items, Cumulative value of consumed items=%.3f\n", i, totalRemoved);
            }
        }
        System.out.println("Consumer: Finished consuming " + maxToRemove + " items");
    }
}
