
public class BoundedBuffer {

    Double[] resource;
    int bufferSize;
    int inCounter = 0;
    int outCounter = 0;
    
    // flags signaling state of buffer
    // do nothing on their own, are used to determine wether to wait()
    boolean isEmpty = true;
    boolean isFull = false;

    public BoundedBuffer(int size) {
        this.bufferSize = size;
        this.resource = new Double[bufferSize];
    }

    public void add(Double value) {
        synchronized(this.resource) {
            while (isFull) {
                try {
                    this.resource.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            // add value in increment inCounter
            this.resource[inCounter] = value;
            this.inCounter = (this.inCounter + 1) % bufferSize;
    
            // buffer will never be empty after adding
            this.isEmpty = false;
            // notify Consumer thread that buffer is no longer empty
            this.resource.notify();
    
            // if in = out after adding, buffer is full
            if (this.inCounter == this.outCounter) {
                this.isFull = true;
            }
        }
    }

    public Double remove() {
        synchronized(this.resource) {
            Double returnValue;
            while (isEmpty) {
                try {
                    this.resource.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            // remove value and increment outCounter
            returnValue = resource[outCounter];
            this.outCounter = (this.outCounter + 1) % bufferSize;
    
            // buffer will never be full after removing
            this.isFull = false;
            // notify Producer thread that buffer is no longer full
            this.resource.notify();
    
            // if in == out after removing, buffer is empty
            if (this.inCounter == this.outCounter) {
                this.isEmpty = true;
            }
            return returnValue;
        }
    }

}