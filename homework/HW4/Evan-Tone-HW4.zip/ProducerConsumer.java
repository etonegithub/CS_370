
public class ProducerConsumer {

    public static void main(String[] args) {   
        // Feature tests
        //Test.runTests();

        // actual assignment specifications
        assignment();

        System.out.println("Exiting!");
    }

    public static void assignment() {
        BoundedBuffer buffer = new BoundedBuffer(1000);
        int numToRun = 1000000;
        int checkpoint = 100000;
        
        Producer prod = new Producer(buffer, numToRun, checkpoint);
        Consumer con = new Consumer(buffer, numToRun, checkpoint);

        Thread prodThread = new Thread(prod);
        Thread conThread = new Thread(con);

        prodThread.start();
        conThread.start();

        try {
            prodThread.join();
            conThread.join();
        } catch (InterruptedException e) {
            System.out.println("Interrupted Exception was caught.");
        }
    }

}