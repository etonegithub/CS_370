import java.util.Random;

public class Producer implements Runnable {

    BoundedBuffer buffer;
    Random random;
    Double totalAdded = 0.0; // sum of all additions
    int maxToAdd;
    int checkpoint;

    public Producer(BoundedBuffer buff, int maxToAdd, int checkpoint) {
        this.buffer = buff;
        this.random = new Random();
        this.maxToAdd = maxToAdd;
        this.checkpoint = checkpoint;
    }

    @Override
    public void run(){
        Double nextNum;    
        for (int i = 0; i <= maxToAdd; i++) {
            // add to buffer and total
            nextNum = random.nextDouble() * 100.0;
            buffer.add(nextNum);
            totalAdded += nextNum;

            // Print updates on predefined checkpoints
            if (i != 0 && (i) % checkpoint == 0) {
                System.out.printf("Producer: Generated %d items, Cumulative value of generated items=%.3f\n", i, totalAdded);
            }
        }
        System.out.println("Producer: Finished generating " + maxToAdd + " items");
    }

}