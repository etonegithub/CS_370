Usage:

> make all
> ./Scheduler <input filepath>
